// db.js
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const app = express();

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'ucss',
  database: 'bdmynegocio'
});

connection.connect(err => {
  if (err) {
    console.error('Error de conexion a BD:', err.stack);
    return;
  }
  console.log('Connectado a MySQL', connection.threadId);
});

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(bodyParser.urlencoded({ extended: true }));

const getData = () => {
  return new Promise((resolve, reject) => {
    const query = 'Select IdCategoria,NombreCategoria from categoria';
    connection.query(query, (error, results) => {
      if (error) return reject(error);
      resolve(results);
    });
  });
};

function getNombCat(idcat) {
    return new Promise((resolve, reject) => {
        connection.query('Select NombreCategoria from categoria where IdCategoria=?',[idcat], (err, results) => {
            if (err) return reject(err);
            resolve(results); 
        });
    });
};


function getPedido(idped) {
    return new Promise((resolve, reject) => {
        connection.query('Select * from vistapedido where IdPedido=?;',[idped], (err, results) => {
            if (err) return reject(err);
            resolve(results); 
        });
    });
};

function getTableData(idcat) {
    return new Promise((resolve, reject) => {
        connection.query('Select IdProducto,NombreProducto,CantidadPorUnidad,PrecioUnidad from producto where IdCategoria=?',[idcat], (err, results) => {
            if (err) return reject(err);
            resolve(results); 
        });
    });
};

function getTableDetalle(idped) {
    return new Promise((resolve, reject) => {
        connection.query('SELECT *,  ROW_NUMBER() OVER (ORDER BY IdPedido) AS Item FROM vistadetalle  where IdPedido=?',[idped], (err, results) => {
            if (err) return reject(err);
            resolve(results); 
        });
    });
};


module.exports = { 
  getData, 
  getTableData, 
  getNombCat,
  getPedido, 
  getTableDetalle 
};
