// app.js
// npm install express-session 
// npm install uuid 

const path = require('path');
const express = require('express');
const PDFDocument = require('pdfkit');
const fs = require('fs');
const { getData } = require('./db');
const { getTableData } = require('./db');
const { getNombCat } = require('./db');
const { getPedido } = require('./db');
const { getTableDetalle } = require('./db');
const session = require('express-session');

const app = express();

app.use(session({ 
  secret: 'ucss_lp2', 
  resave: false, 
  saveUninitialized: false 
}));


app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.urlencoded({ extended: true }));
const port = 3000;

const PDFDocumentWithTables = require('pdfkit-table'); // Use the table plugin
const { constants } = require('buffer');


app.get('/Rpt_Categorias', async (req, res) => {
  try {
    const data = await getData();
    const doc = new PDFDocument();
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename="Categorias.pdf"'); // Force download
    doc.pipe(res); 
    doc.fontSize(25).text('Categorias', 
      { align: 'center' }).moveDown();
    doc.fontSize(12);
    data.forEach(item => {
      doc.text(` ${item.IdCategoria}      ${item.NombreCategoria}`);
    });
    doc.end();
  } catch (error) {
    console.error(error);
    res.status(500).send('Error generando PDF');
  }
});


app.post('/Rpt_Productos', async (req, res) => {
  try {
    res.set('Accept-Ranges', 'none');
    const scat = req.session.sCat; 
console.log("------------------------ ",scat);
    const idcat = scat.idcat;

    const NombCat= scat.nombcat;
    const data = await getTableData(idcat);
    const doc = new PDFDocumentWithTables(); // Initialize with the table plugin's class
    doc.pipe(fs.createWriteStream('./Productos_Cat.pdf')); // Pipe to a file
    doc.fontSize(25).text(NombCat, { align: 'center' }).moveDown();
      
    const table = {
        headers: ["ID", "Producto", "Presentacion", "Precio"],
        rows: data.map(row => [row.IdProducto,
          row.NombreProducto , 
          row.CantidadPorUnidad, 
          row.PrecioUnidad]),
    };
    await doc.table(table, {
        width: 500,
        prepareHeader: () => doc.font("Helvetica-Bold").fontSize(15),
        columnsSize: [ 50, 200, 200,50 ],
        prepareRow: (row, indexColumn, indexRow, rectRow) => {
        doc.font("Helvetica").fontSize(14);
        indexColumn === 0 && doc.addBackground(rectRow, (indexRow % 2 ? 'blue' : 'green'), 0.05);
  }
    });

    doc.end(); 
//    console.log("Generado Productos_Cat.pdf");
//    console.log(__dirname);

    const pdfPath = path.join(__dirname, 'Productos_Cat.pdf'); 
    res.sendFile(pdfPath, (err) => {
        if (err) {
          console.error('Error enviando PDF:', err);
          res.status(500).send('Error cargando PDF.');
        }
      });

  } catch (error) {
    console.error(error);
    res.status(500).send('Error generando PDF');
  }
});

app.post('/Rpt_Pedidos', async (req, res) => {
  try {
    res.set('Accept-Ranges', 'none');
    const idPed = req.body.txtIdPed;
    const RegPed = await getPedido(idPed);
    //console.log(RegPed);
    const data = await getTableDetalle(idPed);
   //console.log(data);
    const doc = new PDFDocumentWithTables(); 
    doc.pipe(fs.createWriteStream('./Pedido.pdf'));
    doc.fontSize(11).moveDown();
    doc.text(`PEDIDO: ${RegPed[0].IdPedido}`, 50, 100);  
    doc.text(`FECHA: ${RegPed[0].FechaPedido}`, 430, 100);  
    doc.moveDown();
    doc.text(``, 50, 130);  
    const table = {
        headers: ["Item", "Producto", "Presentacion", "Precio","Cantidad","Imp.Comp.","Imp.Dscto.","Imp.Vta."],
        rows: data.map(row => [row.Item,
          row.NombreProducto , 
          row.CantidadPorUnidad, 
          row.PrecioUnidad,
          row.Cantidad,
          row.ImpCompra,
          row.ImpDscto,
          row.ImpVta
        ]),
    };
    await doc.table(table, {
        width: 500,
        prepareHeader: () => doc.font("Helvetica-Bold").fontSize(10),
        columnsSize: [ 30, 120, 75,55,55,55,55,55 ],
        prepareRow: (row, indexColumn, indexRow, rectRow) => {
        doc.font("Helvetica").fontSize(10);
        indexColumn === 0 && doc.addBackground(rectRow, (indexRow % 2 ? 'blue' : 'green'), 0.05);
  }
    });

    doc.end(); 

    const pdfPath = path.join(__dirname, 'Pedido.pdf'); 
    res.sendFile(pdfPath, (err) => {
        if (err) {
          console.error('Error enviando PDF:', err);
          res.status(500).send('Error cargando PDF.');
        }
      });

  } catch (error) {
    console.error(error);
    res.status(500).send('Error generando PDF');
  }
});

app.get('/', async (req, res) => {
  try {

    res.render('MenuH', {

    });

  } catch (error) {
    console.log(error);
    res.status(500).send('Error en reportes');
  }
});

app.get('/presCatelogo', async (req, res) => {
  try {
    const IdCat = 0;
    const NombCat = "";
    const Categorias = await getData();
    const Productos =[];
    res.render('Catalogo', {
      Categorias,
      IdCat,
      NombCat,
      Productos
    });

  } catch (error) {
    console.error('🚨 Error al obtener categorías:', error);
    res.status(500).send('Error interno del servidor');
  }
});

app.post('/presCatalogo', async (req, res) => {
  try {
    const idCat1 = req.body.cboCategoria;
    const idCat2 = req.body.idCatx;
    let IdCat=idCat1;
    if(IdCat==0) IdCat=idCat2;
    const Categorias = await getData();
    const Productos = await getTableData(IdCat);
    const NombCat = Categorias[IdCat - 1]?.NombreCategoria || "";

    req.session.sCat = { idcat: IdCat, nombcat: NombCat }; 

    res.render('Catalogo', {
      Categorias:Categorias,
      IdCat,
      NombCat,
      Productos,
    });

  } catch (error) {
    console.error('🚨 Error al procesar el pedido:', error);
    res.status(500).send('Error interno del servidor');
  }
});

app.listen(port, () => {
  console.log(`Servidor escuchando en  http://localhost:${port}`);
});